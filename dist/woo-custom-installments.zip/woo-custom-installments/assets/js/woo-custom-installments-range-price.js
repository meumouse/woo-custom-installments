/**
 * Replace range price
 * 
 * @since 2.8.0
 * @version 3.2.0
 */
jQuery.noConflict()( function($) {
	var originalPrice = get_original_price();

	function get_original_price() {
        var originalPrice = $('.summary .price').html();

        if (!originalPrice) {
            var container_price = $('.price');

            if (container_price.length) {
                container_price.closest('div').addClass('range-price');
                originalPrice = container_price.closest('div').find('.price').html();
            }
        }

        return originalPrice;
    }
  
	$(document).on('found_variation', 'form.variations_form', function(event, variation) {
	  var variationPrice = $('.woocommerce-variation-price .price').html();

	  $('.summary .price, .range-price .price').html(variationPrice);
	  $('.summary .price, .range-price .price').find('.woo-custom-installments-group').removeClass('deprecated');
	});

	$('form.variations_form').on('change', 'select', function() {
		if ($(this).val() === '') {
		  $('.summary .price, .range-price .price').html(originalPrice);
		}

		$('.summary .price, .range-price .price').siblings('.woo-custom-installments-group.deprecated').hide();
	});
  
	$('a.reset_variations').click( function(event) {
	  event.preventDefault();
	  $('.summary .price, .range-price .price').html(originalPrice);
	});
});
/**
 * Replace range price
 * 
 * @since 2.8.0
 */
jQuery( function($) {
	let originalPrice = $('.summary p.price').html();

	$(document).on('found_variation', 'form.variations_form', function( event, variation ) {
		var variationPrice = $('.woocommerce-variation-price .original-price').html();
		$('.summary .price').html(variationPrice);
		$('.woocommerce-variation-price').hide();
	});

	$('a.reset_variations').click( function( event ) {
		event.preventDefault();
		jQuery('.summary p.price').html(originalPrice);
	});
});
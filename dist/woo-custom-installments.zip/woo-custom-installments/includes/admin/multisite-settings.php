<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; } ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">

<div class="d-flex">
    <h1 class="wp-heading-inline wci_main_title"><?php echo get_admin_page_title() ?></h1>
</div>

<div id="wci_section_title-description">
    <p><?php echo esc_html__( 'Em breve configurações para WordPress Multisite.', 'woo-custom-installments' ) ?></p>
</div>
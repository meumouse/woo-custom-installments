<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

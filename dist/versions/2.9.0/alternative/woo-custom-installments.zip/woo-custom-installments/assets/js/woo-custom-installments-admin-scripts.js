(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let activeTabIndex = localStorage.getItem('activeTabIndex');
		
		// Sets the active tab based on the value stored in localStorage
		if (activeTabIndex !== null) {
			$('.woo-custom-installments-wrapper a.nav-tab').eq(activeTabIndex).click();
		}
	});
	  
	$(document).on('click', '.woo-custom-installments-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('activeTabIndex', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.woo-custom-installments-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.woo-custom-installments-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.woo-custom-installments-form').find(attrHref).addClass('active');
		
		return false;
	});

	
	/**
	 * Allow only number bigger or equal 1 in inputs
	 * 
	 * @since 2.0.0
	 */
	$(document).ready( function() {
		let inputField = $('.allow-numbers-be-1');
		
		inputField.on('input', function() {
			let inputValue = $(this).val();
		
			if (inputValue > 1) {
				$(this).val(inputValue);
			} else {
				$(this).val(1);
			}
		});
	});


	/**
	 * Hide toast on click button or after 5 seconds
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		$('.hide-toast').click( function() {
			$('.update-notice-wci').fadeOut('fast');
		});

		setTimeout( function() {
			$('.update-notice-wci').fadeOut('fast');
		}, 5000);
	});


	/**
	 * Get symbol after select option
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		// Change icon on change option selector discount main price
		$('select.get-discount-method-main-price').change( function() {
			let selectedMethod = $(this).children("option:selected").val();

			if (selectedMethod == 'percentage') {
				$('.discount-method-result-main-price').html('%');
			} else {
				$('.discount-method-result-main-price').html(currency_symbol);
			}
		});

		// Change icon on change option selector discount per payment method
		$('select.get-discount-method-payment-method').change( function() {
			let selectedOption = $(this).val();
			let elementId = $(this).closest('.wci-method-discount-selector').attr('id');
			let methodResultId = $('#' + elementId + ' .discount-method-result-payment-method');
			
			if (selectedOption == 'fixed') {
				methodResultId.html(currency_symbol);
			} else if (selectedOption == 'percentage') {
				methodResultId.html('%');
			}
		});

		// Change icon on change option selector interest per payment method
		$('select.get-interest-method-payment-method').change( function() {
			let selectedOption = $(this).val();
			let elementId = $(this).closest('.wci-method-interest-selector').attr('id');
			let methodResultId = $('#' + elementId + ' .interest-method-result-payment-method');
			
			if (selectedOption == 'fixed') {
				methodResultId.html(currency_symbol);
			} else if (selectedOption == 'percentage') {
				methodResultId.html('%');
			}
		});

		// Change icon on change option selector discount main price
		$('select.get-discount-per-quantity-method').change( function() {
			let selectedMethod = $(this).children("option:selected").val();

			if (selectedMethod == 'percentage') {
				$('.discount-per-quantity-method-result').html('%');
			} else {
				$('.discount-per-quantity-method-result').html(currency_symbol);
			}
		});

		// Change icon on change option selector discount main price
		$('select.get-discount-method-ticket').change( function() {
			let selectedMethod = $(this).children("option:selected").val();

			if (selectedMethod == 'percentage') {
				$('.discount-method-result-ticket').html('%');
			} else {
				$('.discount-method-result-ticket').html(currency_symbol);
			}
		});

	});


	/**
	 * Allow insert only numbers and dot in fee installment global
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		$('.allow-number-and-dots').keydown(function(e) {
			let key = e.charCode || e.keyCode || 0;

			return (
				(key >= 96 && key <= 105) ||
				(key >= 48 && key <= 57) ||
				key == 190 || key == 8
			);
		});
	});


	/**
	 * Allow insert only numbers, dot and dash in design tab
	 * 
	 * @since 2.1.0
	 */
	jQuery( function($) {
		$('.design-parameters').keydown(function(e) {
			let key = e.charCode || e.keyCode || 0;

			return (
				(key >= 96 && key <= 105) || // numbers (numeric keyboard)
				(key >= 48 && key <= 57) || // numbers (top keyboard)
				key == 190 || // dot
				key == 189 || key == 109 || // dash
				key == 8 // backspace
			);
		});
	});


	/**
	 * Display loader and hide span on click
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		$('.button-loading').on('click', function() {
			let $btn = $(this);
			let originalText = $btn.text();
			let btnWidth = $btn.width();
			let btnHeight = $btn.height();

			// keep original width and height
			$btn.width(btnWidth);
			$btn.height(btnHeight);

			// Add spinner inside button
			$btn.html('<span class="spinner-border spinner-border-sm"></span>');
		
			setTimeout(function() {
			// Remove spinner
			$btn.html(originalText);
			
			}, 15000);
		});

		// Prevent keypress enter
		$('.form-control').keypress(function(event) {
			if (event.keyCode === 13) {
			event.preventDefault();
			}
		});
	});


	/**
	 * Display foreach custom fee per installment
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		// get visibility on data base
		if( $('#set_fee_per_installment').prop('checked') ) {
			$('#fee-global-settings').addClass('d-none');
			$('#set-custom-fee-per-installment').removeClass('d-none');
			$('#fee_installments_global').prop('disabled', true);
		} else {
			$('#fee-global-settings').removeClass('d-none');
			$('#set-custom-fee-per-installment').addClass('d-none');
			$('#fee_installments_global').prop('disabled', false);
		}

		// change visibility on click
		$('#set_fee_per_installment').click( function() {
			if ($(this).prop('checked')) {
				$('#fee-global-settings').addClass('d-none');
				$('#set-custom-fee-per-installment').removeClass('d-none');
				$('#fee_installments_global').prop('disabled', true);
			} else {
				$('#fee-global-settings').removeClass('d-none');
				$('#set-custom-fee-per-installment').addClass('d-none');
				$('#fee_installments_global').prop('disabled', false);
			}
		});
	});


	/**
	 * Check elements if has class pro-version
	 * 
	 * @since 2.0.0
	 */
	jQuery( function($) {
		$('.pro-version').prop('disabled', true);
	});


	/**
	 * Check if max installments without fee is equal or minus of number installments
	 * 
	 * @since 2.1.0
	 */
	jQuery( function($) {
		let inputMaxInstallmentsWithoutFee = $('#max_qtd_installments_without_fee');
		let inputMaxInstallments = $('#max_qtd_installments');
	
		// adiciona um evento de mudança aos inputs
		inputMaxInstallments.on('input', function() {
			let maxInstallments = parseInt( inputMaxInstallments.val() );
			let maxInstallmentsWithoutFee = parseInt( inputMaxInstallmentsWithoutFee.val() );
		
			if (maxInstallmentsWithoutFee > maxInstallments) {
				inputMaxInstallmentsWithoutFee.val(maxInstallments);
			}
		});
	
		inputMaxInstallmentsWithoutFee.on('input', function() {
			let maxInstallments = parseInt( inputMaxInstallments.val() );
			let maxInstallmentsWithoutFee = parseInt( inputMaxInstallmentsWithoutFee.val() );
		
			if (maxInstallmentsWithoutFee > maxInstallments) {
				inputMaxInstallmentsWithoutFee.val(maxInstallments);
			}
		});
	});


	/**
	 * Disable save options button if options are not different
	 * 
	 * @since 2.3.5
	 */
	jQuery( function($) {
		let saveButton = $('#save_settings');
		let settingsForm = $('form[name="woo-custom-installments"]');

		// get original values of options in the data base wordpress
		let originalValues = settingsForm.serialize();

		// disable button if options are not different
		if (settingsForm.serialize() === originalValues) {
			saveButton.prop('disabled', true);
		} else {
			saveButton.prop('disabled', false);
		}

		// Records a change event on form fields
		settingsForm.on('change', function() {
			// Verifica se houve mudanças nos valores dos campos
			if ( settingsForm.serialize() === originalValues ) {
				// If the values are the same, disable the save button
				saveButton.prop('disabled', true);
			} else {
				// If the values are different, enable the save button
				saveButton.prop('disabled', false);
			}
		});
	});


	/**
	 * Set value zero if interest global is empty
	 * 
	 * @since 2.7.2
	 */
	jQuery( function($) {
		$('#fee_installments_global').blur( function() {
			var input = $(this);
			if (input.val() === '') {
			  input.val('0');
			}
		});
	});


	/**
	 * Change container visibility on click
	 * 
	 * @since 2.7.2
	 */
	jQuery(function($) {

		/**
		 * Function to change container visibility
		 * @param {string} method - activation element selector
		 * @param {string} container - container selector
		 */
		function toggleContainerVisibility(method, container) {
			let checked = $(method).prop('checked');
			$(container).toggleClass('d-none', !checked);
			updatePaymentFormsVisibility();
		}
	
		/**
		 * Function to check the visibility of the ".container-separator.payment-forms" element
		 * and removing the "d-none" class if at least one of the selectors is enabled
		 */
		function updatePaymentFormsVisibility() {
			let anyChecked = $('#enable_pix_method_payment_form').prop('checked') ||
				$('#enable_ticket_method_payment_form').prop('checked') ||
				$('#enable_credit_card_method_payment_form').prop('checked') ||
				$('#enable_debit_card_method_payment_form').prop('checked');
		
			$('.container-separator.payment-forms').toggleClass('d-none', !anyChecked);
		}
	
		/**
		 * Hide input "Texto inicial em produtos variáveis (A partir de)"
		 * 
		 * @since 2.4.0
		 */
		toggleContainerVisibility('#remove_price_range', '#starting-from');
		$('#remove_price_range').click( function() {
			toggleContainerVisibility('#remove_price_range', '#starting-from');
		});
	
		/**
		 * Enable all interest options
		 * 
		 * @since 2.4.0
		 */
		toggleContainerVisibility('#enable_all_interest_options', '.display-enable-all-interest-options');
		$('#enable_all_interest_options').click( function() {
			toggleContainerVisibility('#enable_all_interest_options', '.display-enable-all-interest-options');
		});
		
		/**
		 * Enable all discount options
		 * 
		 * @since 2.4.0
		 */
		toggleContainerVisibility('#enable_all_discount_options', '.display-enable-all-discount-options');
		$('#enable_all_discount_options').click( function() {
			toggleContainerVisibility('#enable_all_discount_options', '.display-enable-all-discount-options');
			$('#discount-settings .container-separator').toggleClass('d-none', !$(this).prop('checked'));
		});

		/**
		 * Active text on active pix method
		 * 
		 * @since 2.7.2
		 */
		toggleContainerVisibility('#enable_pix_method_payment_form', '.admin-container-transfers');
		$('#enable_pix_method_payment_form').click( function() {
			toggleContainerVisibility('#enable_pix_method_payment_form', '.admin-container-transfers');
		});
	
		/**
		 * Active text on active ticket method
		 * 
		 * @since 2.7.2
		 */
		toggleContainerVisibility('#enable_ticket_method_payment_form', '.admin-container-ticket');
		$('#enable_ticket_method_payment_form').click( function() {
			toggleContainerVisibility('#enable_ticket_method_payment_form', '.admin-container-ticket');
		});
	
		/**
		 * Active text on active credit card method
		 * 
		 * @since 2.7.2
		 */
		toggleContainerVisibility('#enable_credit_card_method_payment_form', '.admin-container-credit-card');
		$('#enable_credit_card_method_payment_form').click( function() {
		toggleContainerVisibility('#enable_credit_card_method_payment_form', '.admin-container-credit-card');
		});
	
		/**
		 * Active text on active debit card method
		 * 
		 * @since 2.7.2
		 */
		toggleContainerVisibility('#enable_debit_card_method_payment_form', '.admin-container-debit-card');
		$('#enable_debit_card_method_payment_form').click( function() {
			toggleContainerVisibility('#enable_debit_card_method_payment_form', '.admin-container-debit-card');
		});
	
		/**
		 * Display more settings after active discount per quantity
		 * 
		 * @since 2.7.2
		 */
		toggleContainerVisibility('#enable_functions_discount_per_quantity', '.table-row-set-quantity-enable-discount');
		$('#enable_functions_discount_per_quantity').click( function() {
			toggleContainerVisibility('#enable_functions_discount_per_quantity', '.table-row-set-quantity-enable-discount');
		});

		/**
		 * Hide discount per quantity option
		 * 
		 * @since 2.7.2
		 */
		if( $('#enable_functions_discount_per_quantity').prop('checked') ) {
			// Hide discount per quantity option single product if global is activated
			if( $('#set_discount_per_quantity_global').prop('checked') ) {
				$('.disable-discount-per-product-single').addClass('d-none');
			} else {
				$('.disable-discount-per-product-single').removeClass('d-none');
			}
	
			$('#set_discount_per_quantity_global').click( function() {
				if ($(this).prop('checked')) {
					$('.disable-discount-per-product-single').addClass('d-none');
				} else {
					$('.disable-discount-per-product-single').removeClass('d-none');
				}
			});
	
			// Hide discount per quantity option global if single product is activated
			if( $('#enable_functions_discount_per_quantity_single_product').prop('checked') ) {
				$('.disable-discount-per-product-global').addClass('d-none');
			} else {
				$('.disable-discount-per-product-global').removeClass('d-none');
			}
	
			$('#enable_functions_discount_per_quantity_single_product').click( function() {
				if ($(this).prop('checked')) {
					$('.disable-discount-per-product-global').addClass('d-none');
				} else {
					$('.disable-discount-per-product-global').removeClass('d-none');
				}
			});
		}

		/**
		 * Display custom text after price
		 * 
		 * @since 2.8.0
		 */
		toggleContainerVisibility('#custom_text_after_price', '.tr-custom-text-after-price');
		$('#custom_text_after_price').click( function() {
			toggleContainerVisibility('#custom_text_after_price', '.tr-custom-text-after-price');
		});

		/**
		 * Display discount ticket option
		 * 
		 * @since 2.8.0
		 */
		toggleContainerVisibility('#enable_ticket_method_payment_form', '.admin-discount-ticket-option');
		$('#enable_ticket_method_payment_form').click( function() {
			toggleContainerVisibility('#enable_ticket_method_payment_form', '.admin-discount-ticket-option');
		});
	});


	/**
	 * Modal Pro notice
	 * 
	 * @since 2.7.5
	 */
	jQuery( function($) {
		const popupProNotice = $('.pro-version-notice');
		const popupProContainer = $('#popup-pro-notice');
		const closePopupProNotice = $('#close-pro-notice');
		
		popupProNotice.on('click', function() {
		popupProContainer.addClass('show');
		});
		
		popupProContainer.on('click', function(event) {
		if (event.target === this) {
			$(this).removeClass('show');
		}
		});

		closePopupProNotice.on('click', function() {
			popupProContainer.removeClass('show');
		})
	});


	/**
	 * Display immediate aprove badge option
	 * 
	 * @since 2.8.0
	 */
	jQuery( function($) {
		// get visibility on data base
		if( $('#enable_pix_method_payment_form, #enable_credit_card_method_payment_form, #enable_debit_card_method_payment_form').prop('checked') ) {
			$('.admin-immediate-aprove-badge').removeClass('d-none');
		} else {
			$('.admin-immediate-aprove-badge').addClass('d-none');
		}

		// change visibility on click
		$('#enable_pix_method_payment_form, #enable_credit_card_method_payment_form, #enable_debit_card_method_payment_form').click( function() {
			if ($(this).prop('checked')) {
				$('.admin-immediate-aprove-badge').removeClass('d-none');
			} else {
				$('.admin-immediate-aprove-badge').addClass('d-none');
			}
		});
	});


	/**
	 * Hide position select payment form button
	 * 
	 * @since 2.9.0
	 */
	jQuery( function($) {
		// Quando o valor do select for alterado
		$("select[name='display_installment_type']").on("change", function() {
			// check if value is 'hide'
			if ($(this).val() === "hide") {
				$(".tr-position-installment-type-button").addClass("d-none");
			} else {
				$(".tr-position-installment-type-button").removeClass("d-none");
			}
		});
	});

})(jQuery);
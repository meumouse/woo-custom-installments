/**
 * Replace range price
 * 
 * @since 2.8.0
 */
jQuery( function($) {
	let originalPrice = $('.summary .price').html();

	$(document).on('found_variation', 'form.variations_form', function( event, variation ) {
		var variationPrice = $('.woocommerce-variation-price .price').html();
		$('.summary .price').html(variationPrice);
	});

	$('a.reset_variations').click( function( event ) {
		event.preventDefault();
		jQuery('.summary .price').html(originalPrice);
	});
});
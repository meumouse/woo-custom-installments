(function ( $ ) {
	'use strict';

	/**
	 * Update checkout on change values
	 * 
	 * @since 2.0.0
	 */
	$(function () {
		$( document.body ).on( 'change', 'input[name="payment_method"]', function () {
			$( 'body' ).trigger( 'update_checkout' );
		});
	});
}( jQuery ));


/**
 * Accordion installments
 * 
 * @since 2.0.0
 */
jQuery(function($) {
    $('.accordion-header').click(function() {
        let content = $(this).next('.accordion-content');
		
        if (content.css('max-height') == '0px') {
            content.css('max-height', content.prop('scrollHeight') + 'px');
            content.parent('.accordion-item').addClass('active');
        } else {
            content.css('max-height', '0px');
            content.parent('.accordion-item').removeClass('active');
        }
    });
});


/**
 * Modal installments
 * 
 * @since 2.0.0
 */
jQuery( function($) {
	const openPopupButton = $('#open-popup');
	const popupContainer = $('#popup-container');
	const closePopup = $('#close-popup');
	
	openPopupButton.on('click', function() {
	  popupContainer.addClass('show');
	});
	
	popupContainer.on('click', function(event) {
	  if (event.target === this) {
		$(this).removeClass('show');
	  }
	});

	closePopup.on('click', function() {
		popupContainer.removeClass('show');
	})
});


/**
 * Add class for center element group in single product
 * 
 * @since 2.2.0
 */
jQuery( function($) {
    if ( $('body').hasClass('single-product') ) {
      let $installmentsGroup = $('.product').find('.price').siblings('.woo-custom-installments-group');
      // faz alguma coisa com o elemento encontrado, por exemplo:
      $installmentsGroup.addClass('single-product');
    }
});
/**
 * Disable input Fee installment global if is active option
 * 
 * @since 1.3.0
 */
jQuery(function($) {
  if ($('#woo_custom_installments_set_interest_per_installment').attr('checked')) {
    $('#woo_custom_installments_fee_interest').prop('disabled', true);
  }
  else {
      $('#woo_custom_installments_fee_interest').prop('disabled', false);
  }
});
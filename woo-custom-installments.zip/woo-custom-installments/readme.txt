=== Parcelas Customizadas para WooCommerce ===
Contributors: meumouse
Tags: parcelas, parcelamento de produtos, parcelas avançadas, parcelas customizadas, woocommerce
Requires at least: 5.0
Tested up to: 6.0.3
Stable tag: 6.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Extensão que permite exibir o parcelamento e preço com desconto para lojas WooCommerce.

== Description ==

O plugin Parcelas Customizadas para WooCommerce permite informar aos seus clientes em quantas vezes podem parcelar suas compras,
quantas parcelas sem juros, desconto no pagamento por Pix, Boleto, ou outra forma que você queira.

A função deste plugin é apenas visual e informativa, não modifica valores no backend, é necessário que utilize outro plugin oferecer descontos por método de pagamento.

Desenvolvido com o framework Bootstrap 5.2.2, oferece estilos nativamente ao plugin, mas caso seu tema ofereça esse recurso você poderá desabilitar o carregamento do CSS.

Funciona com qualquer tema do WordPress.

Integrado com o plugin PagSeguro (Cálculo de parcelas baseado em fator de multiplicação, veja nossa central de ajuda.)

== Installation ==

Instale o Parcelas Customizadas para WooCommerce através do repositório de plugins WordPress.org ou fazendo upload dos arquivos para o seu servidor.

Ative o plugin Parcelas Customizadas para WooCommerce.

Ao ativar o plugin clique em "Configurar" nos links do plugin para seguir até a seção de configurações do plugin.

Defina os valores de taxas e descontos e salve para alterar as configurações padrão.

== Screenshots ==

1. Popup com os detalhes das parcelas na página de produto único do WooCommerce.
2. Exibição das informações de parcelas nos arquivos de produtos.
3. Aba de configurações no painel do WooCommerce.
4. Aba de configurações no painel do WooCommerce.
5. Configurações do cálculo de parcelamento do plugin PagSeguro.

== Changelog ==

= 1.1.2 =
* Correção de bugs

= 1.1.0 =
* Correção de bugs
* Remoção da opção "Sempre exibir o preço do boleto"

= 1.0.5 =
* Correção de bugs

= 1.0.0 =
* Initial version
<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }

class Woo_Custom_Installments_Custom_Fee_Per_Installment {

  public function __construct() {
    add_filter( 'woo_custom_installments_settings', array( $this, 'pagseguro_fields' ) );
    add_action( 'woocommerce_admin_field_pagseguro_fees', array( $this, 'pagseguro_fees_field' ) );
    add_filter( 'woo_custom_installments_with_fee', array( $this, 'pagseguro_installment_with_fee' ), 200, 4 );
    add_filter( 'woo_custom_installments_dynamic_table_params', array( $this, 'add_pagseguro_fees' ) );
  }

  function pagseguro_fields( $settings ) {
      $new_settings = array(
        array(
          'name' => 'Configurar taxa de juros por parcela',
          'type' => 'title',
        ),
        array(
          'title'   => __( 'Tipo do cálculo', 'woo-custom-installments' ),
          'desc'    => __( 'Se ativado irá calcular a taxa de juros por método fator multiplicador, se desativado em porcentagem.', 'woo-custom-installments' ),
          'id'      => 'woo_custom_installments_type_custom_calc',
          'class'   => 'toggle-switch',
          'default' => 'no',
          'type'    => 'checkbox'
        ),
        array(
          'type' => 'pagseguro_fees',
          'id'   => 'woo_custom_installments_custom_fees',
          'class'   => 'form-control',
          'title' => 'Taxas de juros',
        ),
        array(
          'type' => 'sectionend',
          'id' => 'wcsp-pagseguro-fees-end',
        ),
      );

      $settings = array_merge( $settings, $new_settings );

    return $settings;
  }


  public function pagseguro_fees_field( $value ) {
    $option_value = get_option( $value['id'], $value['default'] );

    ?>
    <tr valign="top">
      <th scope="row" class="titledesc">
        <label for="<?php echo esc_attr( $value['id'] ); ?>"><?php echo esc_html( $value['title'] ); ?></label>
      </th>
      <td class="forminp forminp-text">
        <fieldset>
          <?php
            for ( $i = 1; $i <= get_option( 'woo_custom_installments_max_installments' ); $i++ ) :
              $interest = isset( $option_value[ $i ] ) ? $option_value[ $i ] : '';
          ?>
          <div class="input-group mb-2">
            <p data-installment="<?php echo $i; ?>">
              <input class="small-input form-control" id="custom-installment-first" type="text" value="<?php echo $i; ?>"
                <?php disabled( 1, true ); ?> />
              <input class="small-input form-control" id="custom-installment-secondary" type="text"
                placeholder="0,00"
                name="<?php echo esc_attr( $value['id'] ); ?>[<?php echo $i; ?>]"
                id="<?php echo esc_attr( $value['id'] ); ?>" value="<?php echo wc_format_localized_price( $interest ) ?>" />
            </p>
          </div>
          <?php endfor; ?>
        </fieldset>
      </td>
    </tr>
    <?php
  }

  public function pagseguro_installment_with_fee( $installment_price, $value, $fee, $installments ) {
    $get_type_calc = get_option( 'woo_custom_installments_type_custom_calc' );
    $method = get_option( 'woo_custom_installments_custom_fees', array() );
    $method = array_filter( $method );

    return $installment_price;
  }


  public function add_pagseguro_fees( $args ) {
    $get_type_calc = get_option( 'woo_custom_installments_type_custom_calc' );
    $method = get_option( 'woo_custom_installments_custom_fees', array() );
    $method = array_filter( $method );

    if ( $get_type_calc === 'yes' ) {
      $args['pagseguro_fees'] = array_map( function($value) {
        return wc_format_decimal( $value, 6 );
      }, $method );

      return $args;
    }
    else {
      $args['pagseguro_fees'] = array_map( function($value) {
        return wc_format_decimal( $value, 2 );
      }, $method );

      return $args;
    }

  }
}

new Woo_Custom_Installments_Custom_Fee_Per_Installment();
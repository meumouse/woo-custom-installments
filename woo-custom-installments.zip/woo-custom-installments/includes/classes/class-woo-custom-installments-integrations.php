<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }


/**
 * Integration functions
 *
 * @package  MeuMouse.com
 * @since  2.1.0
 */

class Woo_Custom_Installments_Integrations extends Woo_Custom_Installments_Init {


  public function __construct() {
    parent::__construct();

    $this->woo_custom_installments_woodmart_integration();
  }

  /**
   * Integration with Woodmart theme
   * 
   * @return string
   * @since 2.1.0
   */
  public function woo_custom_installments_woodmart_integration() {

    // check if woodmart is activated
    if( get_option( 'woodmart_is_activated' ) == '1' ) {
        remove_filter( 'woocommerce_get_price_html', array( $this, 'discount_main_price' ), 999, 2 );
    }
  }

}

new Woo_Custom_Installments_Integrations();
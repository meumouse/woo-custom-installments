(function ( $ ) {
	'use strict';

	/**
	 * Update checkout on change values
	 * 
	 * @since 2.0.0
	 */
	$(function () {
		$( document.body ).on( 'change', 'input[name="payment_method"]', function () {
			$( 'body' ).trigger( 'update_checkout' );
		});
	});
}( jQuery ));


/**
 * Accordion installments
 * 
 * @since 2.0.0
 */
jQuery( function($) {
	$('.accordion-header').click( function() {
		$(this).closest('.accordion-item').toggleClass('active');
	});
});

/**
 * Modal installments
 * 
 * @since 2.0.0
 */
jQuery( function($) {
	const openPopupButton = $('#open-popup');
	const popupContainer = $('#popup-container');
	const closePopup = $('#close-popup');
	
	openPopupButton.on('click', function() {
	  popupContainer.addClass('show');
	});
	
	popupContainer.on('click', function(event) {
	  if (event.target === this) {
		$(this).removeClass('show');
	  }
	});

	closePopup.on('click', function() {
		popupContainer.removeClass('show');
	})
});